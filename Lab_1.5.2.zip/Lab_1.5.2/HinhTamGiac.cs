﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._5._2
{
    class HinhTamGiac : Hinh
    {
        public double a { get; set; }
        public double b { get; set; }
        public double c { get; set; }

        public HinhTamGiac(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public override double TinhChuVi()
        {
            return a + b + c;
        }

        public override double TinhDienTich()
        {
            double p = TinhChuVi() / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
        }

        public override string ToString()
        {
            return $"Hinh Tam Giac: a = {a}, b = {b}, c = {c}, Chu Vi = {TinhChuVi()}, Dien Tich = {TinhDienTich()}";
        }
    }
}
