﻿//Bài 2: Xây dựng chương trình tính chu vi và diện tích hình tròn, vuông, tam giác, chữ nhật
//Gợi ý:
//-Tạo một lớp “Hinh” có phương thức ảo tính chu vi, diện tích
//- Tạo các lớp: “HinhTron”, “HinhVuong”, “HinhTamGiac”, “HinhChuNhat” kế thừa từ class “Hinh” và định nghĩa các hàm tính chu vi, diện tích
//- Tạo List chỉ các Hinh. Tính tổng chu vi và tổng diện tích các hình trong List

namespace Lab_1._5._2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Hinh> hinhList = new List<Hinh>();
            double TongChuVi = 0;
            double TongDienTich = 0;
            hinhList.Add(new HinhTron(5));
            hinhList.Add(new HinhVuong(4));
            hinhList.Add(new HinhChuNhat(3, 6));
            hinhList.Add(new HinhTamGiac(3, 4, 5));
            foreach (Hinh h in hinhList)
            {
                TongChuVi += h.TinhChuVi();
                TongDienTich += h.TinhDienTich();
                Console.WriteLine(h.ToString());
            }
            Console.WriteLine($"Tong Chu Vi: {TongChuVi}");
            Console.WriteLine($"Tong Dien Tich: {TongDienTich}");

        }
    }
}
