﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab_1._5._2;
//Bài 2: Xây dựng chương trình tính chu vi và diện tích hình tròn, vuông, tam giác, chữ nhật
//Gợi ý:
//-Tạo một lớp “Hinh” có phương thức ảo tính chu vi, diện tích
//- Tạo các lớp: “HinhTron”, “HinhVuong”, “HinhTamGiac”, “HinhChuNhat” kế thừa từ class “Hinh” và định nghĩa các hàm tính chu vi, diện tích
//- Tạo List chỉ các Hinh. Tính tổng chu vi và tổng diện tích các hình trong List
namespace Lab_1._5._2
{
    abstract class Hinh
    {
        public abstract double TinhChuVi();
        public abstract double TinhDienTich();
    }

}
