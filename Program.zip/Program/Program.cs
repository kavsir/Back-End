﻿////1Viết chương trình nhập vào tên và tuổi, sau đó in ra màn hình thông báo "Xin chào[tên], bạn[tuổi] tuổi!"
Console.OutputEncoding = System.Text.Encoding.UTF8;

//string? name;
//int age;
////nhap du lieu
//Console.WriteLine("nhap ten: ");
//name=Console.ReadLine();
//Console.WriteLine("nhap tuoi: ");
//age = int.Parse(Console.ReadLine() ?? "0");
//Console.WriteLine($"Xin chao {name}, ban {age} tuoi!");

//double chieudai, chieurong;
//try
//{
//    Console.WriteLine("chieu dau: ");
//    chieudai = double.Parse(Console.ReadLine() ?? "0");
//    Console.WriteLine("chieu rong: ");
//    chieurong = double.Parse(Console.ReadLine() ?? "0");
    
//    if(chieurong <= 0 || chieudai <=0)
//    {
//        throw new Exception("chieu rong va chieu dai phai lon hon 0");
//    }

//    Console.WriteLine($"dien tich hinh chu nhat la: {chieudai * chieurong}");
//}
//catch(FormatException ex)
//{
//    Console.WriteLine("nhap sai dinh dang" +ex.Message);
//}
//catch (Exception ex)
//{
//    Console.WriteLine("loi khac"+ ex.Message);
//}



//Bài 3: Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ F
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//double doC, doF;
//Console.WriteLine("nhap do C: ");
//doC = double.Parse(Console.ReadLine() ?? "0");
//doF = doC * 9 / 5 + 32;
//Console.WriteLine($"do F la: {doF}");





//Bài 4: Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn hay không.
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int a;
//Console.WriteLine("nhap so nguyen: ");
//a = int.Parse(Console.ReadLine() ?? "0");
//if (a % 2 == 0)
//{
//    Console.WriteLine("so chan");
//}
//else
//{
//    Console.WriteLine("so le");
//}




//Bài 5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int a, b;
//Console.WriteLine("nhap so thu nhat: ");
//a = int.Parse(Console.ReadLine() ?? "0");
//Console.WriteLine("nhap so thu hai: ");
//b = int.Parse(Console.ReadLine() ?? "0");
//Console.WriteLine($"tong cua {a} va {b} la: {a + b}");
//Console.WriteLine($"tich cua {a} va {b} la: {a * b}");





//Bài 6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int a;
//Console.WriteLine("nhap so nguyen: ");
//a = int.Parse(Console.ReadLine() ?? "0");
//if (a > 0)
//{
//    Console.WriteLine("so duong");
//}
//else if (a < 0)
//{
//    Console.WriteLine("so am");
//}
//else
//{
//    Console.WriteLine("so khong");
//}





//Bài 7: Viết chương trình kiểm tra xem một năm nhập vào có phải là năm nhuận hay không.(Năm nhuận là năm chia hết cho 4, trừ các năm chia hết cho 100 nhưng không chia hết cho 400).
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int year;
//Console.WriteLine("nhap nam: ");
//year = int.Parse(Console.ReadLine() ?? "0");
//if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
//{
//    Console.WriteLine("nam nhuan");
//}
//else
//{
//    Console.WriteLine("nam khong nhuan");
//}


//Bài 8: Viết chương trình in ra bảng cửu chương từ 1 đến 10.
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//for (int i = 1; i <= 10; i++)
//{
//    for (int j = 1; j <= 10; j++)
//    {
//        Console.WriteLine($"{i} x {j} = {i * j}");
//    }
//    Console.WriteLine();
//}




//Bài 9: Viết chương trình tính giai thừa của một số nguyên dương n.
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int n;
//Console.WriteLine("nhap so nguyen duong: ");
//n = int.Parse(Console.ReadLine() ?? "0");
//int giaithua = 1;
//for (int i = 1; i <= n; i++)
//{
//    giaithua *= i;
//}
//Console.WriteLine($"giai thua cua {n} la: {giaithua}");




//Bài 10: Viết chương trình kiểm tra xem một số có phải là số nguyên tố hay không.
//Console.OutputEncoding = System.Text.Encoding.UTF8;
//int n;
//Console.WriteLine("nhap so nguyen: ");
//n = int.Parse(Console.ReadLine() ?? "0");
//if (n < 2)
//{
//    Console.WriteLine("khong phai so nguyen to");
//}
//else
//{
//    bool check = true;
//    for (int i = 2; i <= Math.Sqrt(n); i++)
//    {
//        if (n % i == 0)
//        {
//            check = false;
//            break;
//        }
//    }
//    if (check)
//    {
//        Console.WriteLine("la so nguyen to");
//    }
//    else
//    {
//        Console.WriteLine("khong phai so nguyen to");
//    }
//}

