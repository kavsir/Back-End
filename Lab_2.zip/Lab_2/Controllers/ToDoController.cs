﻿using Microsoft.AspNetCore.Mvc;

namespace Lab_2.Controllers
{
    public class ToDoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
