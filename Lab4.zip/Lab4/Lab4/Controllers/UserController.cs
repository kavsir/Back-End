﻿
using Lab4.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4.Controllers
{
    public class UserController : Controller
    {
        static List<User> users = new List<User>()
        {
            new User() { id="1", username="a", password="1", phone="1", email="1@gmail.com" },
            new User() { id="2", username="aa", password="2", phone="22", email="2@gmail.com" },
            new User() { id="3", username="aaa", password="3", phone="333", email="3@gmail.com" },
        };
        public IActionResult Index()
        {
            return View(users);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(User user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users.Add(user);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(String.Empty, ex.Message);
            }
            return View(user);
        }
        public IActionResult Edit(string id)
        {
            var user = users.FirstOrDefault(u => u.id == id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost]
        public IActionResult Edit(User updatedUser)
        {
            if (ModelState.IsValid)
            {
                var user = users.FirstOrDefault(u => u.id == updatedUser.id);
                if (user != null)
                {
                    user.username = updatedUser.username;
                    user.password = updatedUser.password;
                    user.phone = updatedUser.phone;
                    user.email = updatedUser.email;
                }
                return RedirectToAction("Index");
            }
            return View(updatedUser);

        }
        public IActionResult Delete(string id)
        {
            var user = users.FirstOrDefault(u => u.id == id);
            if (user != null)
            {
                users.Remove(user);
            }
            return RedirectToAction("Index");
        }


    }
}
