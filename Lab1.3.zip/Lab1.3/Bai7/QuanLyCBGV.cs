﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QuanLyCBGV
{
    private List<CBGV> danhSach = new List<CBGV>();

    public void NhapDanhSach()
    {
        Console.Write("Nhập số cán bộ giáo viên: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin cán bộ thứ {i + 1}:");
            CBGV cb = new CBGV();
            cb.Nhap();
            danhSach.Add(cb);
        }
    }

    public void HienThiTatCa()
    {
        Console.WriteLine("\n--- Danh sách cán bộ giáo viên ---");
        foreach (var cb in danhSach)
        {
            cb.HienThi();
        }
    }

    public void TimTheoQueQuan(string que)
    {
        var ketQua = danhSach.Where(cb => cb.QueQuan.Contains(que)).ToList();
        if (ketQua.Count > 0)
        {
            Console.WriteLine($"\n--- Cán bộ giáo viên quê {que} ---");
            foreach (var cb in ketQua)
            {
                cb.HienThi();
            }
        }
        else
        {
            Console.WriteLine("Không tìm thấy cán bộ giáo viên nào!");
        }
    }

    public void HienThiLuongTren5Trieu()
    {
        var ketQua = danhSach.Where(cb => cb.LuongThucLinh > 5000000).ToList();
        Console.WriteLine("\n--- Cán bộ giáo viên có lương thực lĩnh trên 5 triệu ---");
        if (ketQua.Count > 0)
        {
            foreach (var cb in ketQua)
            {
                cb.HienThi();
            }
        }
        else
        {
            Console.WriteLine("Không có cán bộ nào có lương trên 5 triệu.");
        }
    }
}
