﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class QLCB
{
    private List<CanBo> danhSachCB = new List<CanBo>();

    public void ThemCanBo()
    {
        Console.WriteLine("Chọn loại cán bộ cần nhập:");
        Console.WriteLine("1. Công nhân");
        Console.WriteLine("2. Kỹ sư");
        Console.WriteLine("3. Nhân viên");
        Console.Write("Lựa chọn: ");
        int loai = int.Parse(Console.ReadLine());

        CanBo cb = null;

        switch (loai)
        {
            case 1:
                cb = new CongNhan();
                break;
            case 2:
                cb = new KySu();
                break;
            case 3:
                cb = new NhanVien();
                break;
            default:
                Console.WriteLine("Lựa chọn không hợp lệ.");
                return;
        }

        cb.Nhap();
        danhSachCB.Add(cb);
        Console.WriteLine("Đã thêm cán bộ.\n");
    }

    public void HienThiDanhSach()
    {
        if (danhSachCB.Count == 0)
        {
            Console.WriteLine("Danh sách trống.");
            return;
        }

        Console.WriteLine("\nDanh sách cán bộ:");
        foreach (var cb in danhSachCB)
        {
            cb.HienThi();
            Console.WriteLine("----------");
        }
    }

    public void TimKiemTheoTen()
    {
        Console.Write("Nhập họ tên cần tìm: ");
        string ten = Console.ReadLine();
        var ketQua = danhSachCB.Where(cb => cb.HoTen.ToLower().Contains(ten.ToLower())).ToList();

        if (ketQua.Count == 0)
        {
            Console.WriteLine("Không tìm thấy cán bộ nào.");
            return;
        }

        Console.WriteLine("\nKết quả tìm kiếm:");
        foreach (var cb in ketQua)
        {
            cb.HienThi();
            Console.WriteLine("----------");
        }
    }
}
