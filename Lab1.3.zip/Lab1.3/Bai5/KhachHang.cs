﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class KhachSan
{
    private List<KhachThue> danhSach = new List<KhachThue>();

    public void NhapDS()
    {
        Console.Write("Nhập số lượng khách: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin khách thứ {i + 1}:");
            KhachThue khach = new KhachThue();
            khach.Nhap();
            danhSach.Add(khach);
        }
    }

    public void HienThiDS()
    {
        Console.WriteLine("\nDanh sách khách đang trọ:");
        foreach (var khach in danhSach)
        {
            khach.HienThi();
        }
    }

    public void TimTheoTen()
    {
        Console.Write("Nhập họ tên cần tìm: ");
        string ten = Console.ReadLine();
        var ketQua = danhSach.FindAll(k => k.HoTen.ToLower().Contains(ten.ToLower()));
        if (ketQua.Count > 0)
        {
            Console.WriteLine("Kết quả tìm kiếm:");
            foreach (var kh in ketQua)
                kh.HienThi();
        }
        else Console.WriteLine("Không tìm thấy khách nào.");
    }

    public void TinhTienKhach()
    {
        Console.Write("Nhập họ tên khách cần tính tiền: ");
        string ten = Console.ReadLine();
        var khach = danhSach.Find(k => k.HoTen.ToLower().Contains(ten.ToLower()));
        if (khach != null)
        {
            Console.WriteLine($"Tổng tiền: {khach.TinhTien()}");
        }
        else Console.WriteLine("Không tìm thấy khách.");
    }
}

