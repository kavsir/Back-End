﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLPhanSo ql = new QLPhanSo();
        int luaChon;

        do
        {
            Console.WriteLine("\n--- MENU PHÉP TOÁN PHÂN SỐ ---");
            Console.WriteLine("1. Nhập hai phân số A và B");
            Console.WriteLine("2. Tính tổng A + B");
            Console.WriteLine("3. Tính hiệu A - B");
            Console.WriteLine("4. Tính tích A * B");
            Console.WriteLine("5. Tính thương A / B");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    ql.Nhap();
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                    ql.TinhToan(luaChon - 1);
                    break;
                case 0:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Chức năng không hợp lệ!");
                    break;
            }

        } while (luaChon != 0);
    }
}
