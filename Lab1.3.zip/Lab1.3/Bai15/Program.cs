﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyTamGiac ql = new QuanLyTamGiac();
        int luaChon;

        do
        {
            Console.WriteLine("\n=== MENU ===");
            Console.WriteLine("1. Nhập danh sách tam giác");
            Console.WriteLine("2. Hiển thị tất cả tam giác và các phép tính");
            Console.WriteLine("3. Hiển thị các tam giác vuông");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    ql.NhapDanhSach();
                    break;
                case 2:
                    ql.HienThiToanBoTamGiac();
                    break;
                case 3:
                    ql.HienThiTamGiacVuong();
                    break;
                case 0:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    break;
            }
        } while (luaChon != 0);
    }
}
