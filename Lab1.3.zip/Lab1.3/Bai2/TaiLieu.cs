﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class TaiLieu
    {
        public string MaTaiLieu { get; set; }
        public string NhaXuatBan { get; set; }
        public int SoBanPhatHanh { get; set; }

        public virtual void Nhap()
        {
            Console.Write("Nhập mã tài liệu: ");
            MaTaiLieu = Console.ReadLine();
            Console.Write("Nhập nhà xuất bản: ");
            NhaXuatBan = Console.ReadLine();
            Console.Write("Nhập số bản phát hành: ");
            SoBanPhatHanh = int.Parse(Console.ReadLine());
        }

        public virtual void HienThi()
        {
            Console.WriteLine($"Mã: {MaTaiLieu}, NXB: {NhaXuatBan}, Số bản: {SoBanPhatHanh}");
        }
    }

}
