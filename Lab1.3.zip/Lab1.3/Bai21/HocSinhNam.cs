﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HocSinhNam : HocSinh
{
    public double DiemKyThuat { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập điểm Kỹ thuật: ");
        DiemKyThuat = double.Parse(Console.ReadLine());
    }

    public override void Xuat()
    {
        base.Xuat();
        Console.WriteLine($"Kỹ thuật: {DiemKyThuat}");
    }
}
