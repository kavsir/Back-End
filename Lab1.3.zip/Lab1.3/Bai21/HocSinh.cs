﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class HocSinh
{
    public string HoTen { get; set; }
    public bool GioiTinh { get; set; } // true: Nam, false: Nữ
    public double Toan { get; set; }
    public double Ly { get; set; }
    public double Hoa { get; set; }

    public HocSinh() { }

    public HocSinh(string hoTen, bool gioiTinh, double toan, double ly, double hoa)
    {
        HoTen = hoTen;
        GioiTinh = gioiTinh;
        Toan = toan;
        Ly = ly;
        Hoa = hoa;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhập họ tên: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhập giới tính (nam/nữ): ");
        string gt = Console.ReadLine().Trim().ToLower();
        GioiTinh = gt == "nam";

        Console.Write("Nhập điểm Toán: ");
        Toan = double.Parse(Console.ReadLine());
        Console.Write("Nhập điểm Lý: ");
        Ly = double.Parse(Console.ReadLine());
        Console.Write("Nhập điểm Hóa: ");
        Hoa = double.Parse(Console.ReadLine());
    }

    public virtual void Xuat()
    {
        Console.WriteLine($"Họ tên: {HoTen}, Giới tính: {(GioiTinh ? "Nam" : "Nữ")}, Toán: {Toan}, Lý: {Ly}, Hóa: {Hoa}");
    }
}
