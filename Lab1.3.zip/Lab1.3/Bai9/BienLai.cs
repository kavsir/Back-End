﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class BienLai
{
    public KhachHang Khach { get; set; } = new KhachHang();
    public int ChiSoCu { get; set; }
    public int ChiSoMoi { get; set; }

    public void Nhap()
    {
        Khach.Nhap();
        Console.Write("Nhập chỉ số cũ: ");
        ChiSoCu = int.Parse(Console.ReadLine());
        Console.Write("Nhập chỉ số mới: ");
        ChiSoMoi = int.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Khach.HienThi();
        Console.WriteLine($"Chỉ số cũ: {ChiSoCu}, Chỉ số mới: {ChiSoMoi}, Tiền điện: {TinhTien()} VNĐ");
    }

    public int TinhTien()
    {
        int soDien = ChiSoMoi - ChiSoCu;
        if (soDien <= 50)
            return soDien * 1250;
        else if (soDien < 100)
            return (50 * 1250) + (soDien - 50) * 1500;
        else
            return (50 * 1250) + (50 * 1500) + (soDien - 100) * 2000;
    }
}

public class QuanLyBienLai
{
    private List<BienLai> danhSachBienLai = new List<BienLai>();

    public void NhapDanhSach()
    {
        Console.Write("Nhập số hộ dân: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin hộ dân thứ {i + 1}:");
            BienLai bl = new BienLai();
            bl.Nhap();
            danhSachBienLai.Add(bl);
        }
    }

    public void HienThiDanhSach()
    {
        Console.WriteLine("\n--- Danh sách biên lai ---");
        foreach (var bl in danhSachBienLai)
        {
            bl.HienThi();
            Console.WriteLine("----------------------------");
        }
    }
}

