﻿// File: Controllers/ProductController.cs
using Microsoft.AspNetCore.Mvc;
using Lab3.Models; // dùng namespace Lab3.Models
using System.Collections.Generic;

namespace Lab3.Controllers
{
    public class ProductController : Controller
    {
        // Danh sách sản phẩm lưu trong RAM
        static List<Product> products = new List<Product>()
        {
            new Product() { Id = 1, Name = "Laptop Dell XPS 15", Price = 35999.99M },
            new Product() { Id = 2, Name = "MacBook Pro 14", Price = 54999.99M }
        };

        // Hiển thị danh sách sản phẩm
        public IActionResult Index()
        {
            return View(products);
        }

        // Hiển thị chi tiết sản phẩm
        public IActionResult Details(int id)
        {
            var product = products.Find(p => p.Id == id);
            if (product == null) return NotFound();
            return View(product);
        }

        // Hiển thị form thêm sản phẩm mới
        public IActionResult Create()
        {
            return View();
        }

        // Xử lý thêm mới sản phẩm
        [HttpPost]
        public IActionResult Create(Product product)
        {
            product.Id = products.Count + 1;
            products.Add(product);
            return RedirectToAction("Index");
        }
    }
}
