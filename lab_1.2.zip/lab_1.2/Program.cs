﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
//bai 1. Viết một hàm để tính tổng của tất cả các số chẵn trong một mảng.
int SumEven(int[] arr)
{
    int sum = 0;
    foreach (int i in arr)
    {
        if (i % 2 == 0)
        {
            sum += i;
        }
    }
    return sum;
}




//Bài 2: Viết chương trình nhập vào mảng gồm n phần tử nhập từ bàn phím. Viết hàm để kiểm
//tra xem một số có phải là số nguyên tố hay không, hiển thị chỉ số và giá trị của những phần tử
//là số nguyên tố trong mảng
bool IsPrime(int n)
{
    if (n < 2)
    {
        return false;
    }
    for (int i = 2; i <= Math.Sqrt(n); i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}

//Console.Write("Nhập số phần tử của mảng: ");
//int n = int.Parse(Console.ReadLine());
//int[] arr = new int[n];

//for (int i = 0; i < n; i++)
//{
//    Console.Write($"Nhập phần tử thứ {i + 1}: ");
//    arr[i] = int.Parse(Console.ReadLine());
//}

//Console.WriteLine("Các số nguyên tố trong mảng là:");
//for (int i = 0; i < n; i++)
//{
//    if (IsPrime(arr[i]))
//    {
//        Console.WriteLine($"Chỉ số {i}, Giá trị {arr[i]}");
//    }
//}





// bài 3.Viết một hàm để đếm số lượng số âm và số dương trong một mảng gồm n phần tử nhập từ bàn phím

void ktraAmvDuong(int[] arr)
{
    int demAm = 0;
    int demDuong = 0;
    foreach (int i in arr)
    {
        if (i < 0)
        {
            demAm++;
        }
        else
        {
            demDuong++;
        }
    }
    Console.WriteLine($"Số lượng số âm trong mảng là: {demAm}");
    Console.WriteLine($"Số lượng số dương trong mảng là: {demDuong}");
}





//bài 4. Viết hàm để tìm số lớn thứ hai trong một mảng các số nguyên.
int solonthu2(int[] arr)
{
    int max1 = int.MinValue;
    int max2 = int.MinValue;
    foreach (int i in arr)
    {
        if (i > max1)
        {
            max2 = max1;
            max1 = i;
        }
        else if (i > max2 && i < max1)
        {
            max2 = i;
        }
    }
    return max2;
}

//Bài 5: Viết hàm hoán vị 2 số nguyên a và b nhập từ bàn phím.
void swap(ref int a, ref int b)
{
    int temp = a;
    a = b;
    b = temp;
}

//Bài 6: Viết hàm sắp xếp mảng số thực n phần tử nhập từ bàn phím theo chiều tăng dần.
void sapxepTang(ref double[] arr)
{
    Array.Sort(arr);
}