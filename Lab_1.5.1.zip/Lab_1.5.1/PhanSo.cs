﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._5._1
{
     class PhanSo
    {
        private int? tuSo { get; set; }
        private int? mauSo { get; set; }
        public PhanSo(int tu, int mau)
        {
            this.tuSo = tu;
            this.mauSo = mau;
        }
        public void nhap()
        {
            Console.WriteLine("Nhập tử số: ");
            tuSo = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhập mẫu số: ");
            mauSo = int.Parse(Console.ReadLine());
            while (mauSo == 0)
            {
                Console.WriteLine("Mẫu số không được bằng 0. Nhập lại mẫu số: ");
                mauSo = int.Parse(Console.ReadLine());
            }
        }
        
        public static PhanSo Cong(PhanSo ps1, PhanSo ps2)
        {
            PhanSo tong = new PhanSo(0,0 );
            tong.tuSo = ps1.tuSo * ps2.mauSo + ps2.tuSo * ps1.mauSo;
            tong.mauSo = ps1.mauSo * ps2.mauSo;
            return tong;
        }

        public override string ToString()
        {
            return $"{tuSo}/{mauSo}";
        }

    }
}
