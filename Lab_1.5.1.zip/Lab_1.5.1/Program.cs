﻿
namespace Lab_1._5._1
{

    class Program
    {
        static void Main(string[] args)
        {
            List<PhanSo> phanSoList = new List<PhanSo>();
            Console.WriteLine("Nhập số lượng phân số: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Nhập phân số thứ {i + 1}: ");
                PhanSo ps = new PhanSo(0, 0);
                ps.nhap();
                phanSoList.Add(ps);
            }
            PhanSo tong = new PhanSo(0, 1); 
            foreach (var ps in phanSoList) 
            {
                tong = PhanSo.Cong(tong, ps);
            }

            Console.WriteLine("Tổng các phân số là: " + tong);
        }
    }
}