﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._4
{
    class User
    {
        public string? id { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string ToString()
        {
            return $"{id}\t\t{Username}\t\t{Password}\t\t{Email}\t\t{Phone}";
        }

    }
}
